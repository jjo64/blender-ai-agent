﻿# 🤖 Blender AI Agent

[![Blender](https://img.shields.io/badge/Blender-4.2%2B-orange.svg)](https://www.blender.org/)
[![Python](https://img.shields.io/badge/Python-3.10%2B-blue.svg)](https://www.python.org/)
[![License: GPL-2.0](https://img.shields.io/badge/License-GPL%202.0-green.svg)](https://www.gnu.org/licenses/gpl-2.0.html)
[![Tests](https://img.shields.io/badge/Tests-30%2F30%20Passing-brightgreen.svg)]()

> **Agente de Inteligencia Artificial de nivel de producción para Blender** con arquitectura ReAct, soporte Multi-Provider (Anthropic Claude, OpenAI GPT y Google Gemini), streaming en tiempo real, compuertas de seguridad interactivas (Auth Gate), sandbox AST y política de checkpoints.

---

## 🌟 Características Principales

- **🔌 Soporte Multi-Proveedor (Multi-Provider):**
  - **Anthropic:** Claude 3.7 Sonnet, Claude 3.5 Haiku.
  - **OpenAI:** GPT-4o, GPT-4o-mini, o1.
  - **Google Gemini:** Gemini 2.0 Flash, Gemini 1.5 Pro.
  - *Implementación nativa en `urllib` sin dependencias externas de pip.*

- **⚡ Streaming en Tiempo Real (UX sin bloqueos):**
  - Modelo de concurrencia seguro mediante `TaskBridge` y `queue.Queue`.
  - El Main Thread de Blender consume tokens mediante `bpy.app.timers` a 20 Hz sin congelar el 3D Viewport.
  - Buffering inteligente de llamadas a herramientas (Tool Calls) para evitar JSONs corruptos durante el stream.

- **🛡️ Seguridad Estricta y Supervisión Humana:**
  - **Compuerta de Autorización (`AuthGate`):** Pausa el hilo de fondo con `threading.Event` para solicitar confirmación del usuario antes de ejecutar acciones destructivas o scripts.
  - **Sandbox AST (`SecurityASTVisitor`):** Analiza el árbol de sintaxis abstracta bloqueando módulos peligrosos (`os`, `sys`, `subprocess`, `socket`, `requests`, `eval`, `exec`, `open`).
  - **Credenciales Seguras:** Las API Keys se almacenan en `bpy.types.AddonPreferences` en el perfil de usuario de Blender (`userpref.blend`), nunca en los archivos `.blend`.

- **🔄 Puntos de Restauración (Checkpoints FIFO):**
  - Guarda snapshots temporales de la escena (`.blend`) en `bpy.app.tempdir` antes de cada intervención del agente.
  - Permite hacer rollback instantáneo con un solo clic.

- **👁️ Soporte Multimodal (Visión 3D):**
  - Captura instantánea del 3D Viewport para que el modelo pueda ver la composición, iluminación y objetos activos.

- **💰 Control y Alerta de Costos en Tiempo Real:**
  - Calcula el gasto exacto en USD a partir de los tokens reales devueltos por las APIs.
  - Catálogo de tarifas configurable en `data/prices.json` con alerta de obsolescencia a los 60 días.

---

## 🏗️ Estructura del Proyecto

```text
blender-ai-agent/
├── __init__.py                # Entry point de la extensión para Blender
├── manifest.toml              # Manifiesto de extensión para Blender 4.2+
│
├── core/                      # Lógica de IA pura (100% testeable sin Blender)
│   ├── agent.py               # Máquina de estados ReAct
│   ├── context_manager.py     # Ventana deslizante y Decisiones Inmutables
│   ├── scene_inspector.py     # Captura semántica del estado de la escena
│   ├── tool_registry.py       # Registro declarativo de herramientas (@tool)
│   ├── security/
│   │   ├── auth_gate.py       # Intercepción de acciones con threading.Event
│   │   └── sandbox.py         # Analizador estático de código Python (AST)
│   ├── providers/             # Adaptadores de LLMs (Anthropic, OpenAI, Gemini)
│   └── tracker/
│       └── cost_tracker.py    # Cálculo de consumo y tarifas
│
├── blender_integration/       # Capa de integración con la API de Blender (bpy)
│   ├── tools/                 # Herramientas registradas (mallas, materiales, scripts)
│   ├── state_manager/         # Checkpoints automáticos y restauración
│   ├── viewport_capture.py    # Buffer de imagen PNG para modelos VLM
│   └── threading_model.py     # TaskBridge seguro con colas y timers
│
├── state/                     # Estado de sesión y persistencia local
│   ├── session.py             # Singleton de sesión
│   └── history.py             # Historial persistente en bpy.app.tempdir
│
├── ui/                        # Interfaz gráfica en el 3D Viewport
│   ├── main_panel.py          # Panel lateral N-Panel
│   ├── chat_widget.py         # Operadores de chat y aprobaciones
│   └── settings_panel.py      # Preferencias y API Keys
│
├── data/
│   └── prices.json            # Tarifas por millón de tokens
│
└── tests/                     # Suite completa de pruebas unitarias
```

---

## 🚀 Instalación

### Método 1: Blender 4.2+ (Extensiones)
1. Descarga el repositorio o clónalo dentro de tu directorio de extensiones de Blender.
2. Abre Blender, ve a **Edit > Preferences > Get Extensions** e instala la carpeta del repositorio.

### Método 2: Como Add-on Clásico (.zip)
1. Comprime el contenido del repositorio en un archivo `.zip`.
2. En Blender, ve a **Edit > Preferences > Add-ons > Install...** y selecciona el archivo `.zip`.
3. Activa la casilla **Blender AI Agent**.

---

## ⚙️ Configuración de API Keys

1. Ve a **Edit > Preferences > Add-ons > Blender AI Agent**.
2. Ingresa tus claves de API para los proveedores que desees utilizar (**Anthropic**, **OpenAI** o **Google Gemini**).
3. Configura el límite máximo de iteraciones deseadas (por defecto: 10).

---

## 🧪 Pruebas Unitarias (Quality Assurance)

El proyecto incluye una suite de pruebas unitarias completas que se pueden ejecutar fuera de Blender con Python estándar:

```bash
python -m unittest discover -s tests
```

---

## 📄 Licencia

Este proyecto está bajo la licencia [GPL-2.0-or-later](LICENSE).
